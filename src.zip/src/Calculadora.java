public class Calculadora {

    private double numero1;
    private double numero2;

    public Calculadora(double numero1, double numero2) {
        this.numero1 = numero1;
        this.numero2 = numero2;
    }

    // Metodo para realizar las operaciones
    public double calcular(String operacion) {
        if (operacion.equals("+")) {
            return numero1 + numero2;
        } else if (operacion.equals("-")) {
            return numero1 - numero2;
        }  else if (operacion.equals("*")) {
            return numero1 * numero2;
        } else if (operacion.equals("/")) {
            return numero1 / numero2;
        } else {
            return 0;
        }
    }
}
